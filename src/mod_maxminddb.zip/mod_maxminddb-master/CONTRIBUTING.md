# Contributing #

Pull requests are encouraged. Please run `uncrustify` on your changes using
the included `.uncrustify.cfg` before submitting your pull request.


