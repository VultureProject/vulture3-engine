.. _neural_network_examples:

Neural Networks
-----------------------

Examples concerning the :mod:`sklearn.neural_network` module.
